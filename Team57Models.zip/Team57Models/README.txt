i. DESCRIPTION:

The following two models are meant to accompany Team57FinalReport.docx:
i.1 Team57_Tutorial1Model.alp
i.2 Team57_Tutorial2Model.alp

The reader of this report will recreate these models in AnyLogic by following the installation, basic user guide, and tutorial instructions defined within the report.

ii. INSTALLATION:

These models were created in AnyLogic Personal Learning Edition version 8.7.12 and require an AnyLogic installation to run. 
Please follow the report instructions to install the software if not already installed. 

iii. EXECUTION:

To run the models, simply open the ".alp" files and execute the models by clicking play (green arrow).
The execution of an AnyLogic Model is defined in detail in the report.